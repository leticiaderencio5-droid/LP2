﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_05
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercicio02ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercicio_02 f = new Exercicio_02();
            f.Show();
            this.Hide();
        }

        private void exercicio03ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercicio_03 f = new Exercicio_03();
            f.Show();
            this.Hide();
        }

        private void exercicio01ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercicio_01 f = new Exercicio_01();
            f.Show();
            this.Hide();
        }

        private void exercicio04ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercicio_04 f = new Exercicio_04();
            f.Show();
            this.Hide();
        }
    }
}
