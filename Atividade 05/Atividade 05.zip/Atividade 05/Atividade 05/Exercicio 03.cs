﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_05
{
    public partial class Exercicio_03 : Form
    {
        public Exercicio_03()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string texto = textBox1.Text;

           
            if (texto.Length > 50)
            {
                MessageBox.Show("Texto deve ter no máximo 50 caracteres!");
                return;
            }

            
            texto = texto.Replace(" ", "").ToLower();

            string invertido = "";

            
            for (int i = texto.Length - 1; i >= 0; i--)
            {
                invertido += texto[i];
            }

            
            if (texto == invertido)
            {
               MessageBox.Show("É um palíndromo!");
            }
            else
            {
                MessageBox.Show("Não é um palíndromo!");
            }
        }
    }
}
