﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_05
{
    public partial class Exercicio_04 : Form
    {
        public Exercicio_04()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nome = textBox1.Text;
            string matricula = textBox3.Text;

            int producao;
            double A, gratificacao;

            // valida produção
            if (!int.TryParse(textBox2.Text, out producao))
            {
                MessageBox.Show("Produção inválida!");
                return;
            }

            // valida salário
            if (!double.TryParse(textBox4.Text, out A))
            {
                MessageBox.Show("Salário inválido!");
                return;
            }

            // valida gratificação
            if (!double.TryParse(textBox6.Text, out gratificacao))
            {
                MessageBox.Show("Gratificação inválida!");
                return;
            }

            // definição dos fatores
            int B = (producao >= 100) ? 1 : 0;
            int C = (producao >= 120) ? 1 : 0;
            int D = (producao >= 150) ? 1 : 0;

            // cálculo do salário bruto
            double salarioBruto = A + (A * (0.05 * B + 0.1 * C + 0.1 * D)) + gratificacao;

            // regra do teto de 7000
            if (salarioBruto > 7000)
            {
                if (!(producao >= 150 && gratificacao > 0))
                {
                    salarioBruto = 7000;
                }
            }


            MessageBox.Show("Nome: " + nome + "\n" + "Matrícula: " + matricula + "\n" + "Salário Bruto: R$ " + salarioBruto.ToString("F2"));
        }
    }
}
