﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_05
{
    public partial class Exercicio_02 : Form
    {
        public Exercicio_02()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n;

            
            if (!int.TryParse(textBox1.Text, out n))
            {
                MessageBox.Show("Digite um número válido!");
                return;
            }

           
            if (n <= 0)
            {
                MessageBox.Show("N deve ser maior que 0!");
                return;
            }

            double H = 0.0;

          
            for (int i = 1; i <= n; i++)
            {
                H += 1.0 / i;
            }

            MessageBox.Show("Resultado de H = " + H.ToString("F4"));
        }
    }
}
