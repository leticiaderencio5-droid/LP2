﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_05
{
    public partial class Exercicio_01 : Form
    {
        public Exercicio_01()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string frase = rtbExercicio01.Text;

            if (frase.Length > 100)
            {
                MessageBox.Show("A frase deve ter no máximo 100 caracteres!");
                return;
            }

            int espacos = 0;

            for (int i = 0; i < frase.Length; i++)
            {
                if (frase[i] == ' ')
                {
                    espacos++;
                }
            }

            MessageBox.Show("Espaços em branco: " + espacos);
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            string frase = rtbExercicio01.Text.ToLower(); // deixa tudo minúsculo

            int contadorR = 0;

            for (int i = 0; i < frase.Length; i++)
            {
                if (frase[i] == 'r')
                {
                    contadorR++;
                }
            }

            MessageBox.Show("Quantidade de letras R: " + contadorR);
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            string texto = rtbExercicio01.Text.ToLower();
            int contador = 0;

            for (int i = 0; i < texto.Length - 1; i++)
            {
                if (texto[i] == texto[i + 1] && char.IsLetter(texto[i]))
                {
                    contador++;

                    
                    i++;
                }
            }

            MessageBox.Show("Letras duplas encontradas: " + contador);
        }
    }
        
}
    
    

