﻿namespace Atividade_05
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exercicio01ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercicio02ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercicio03ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercicio04ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exercicio01ToolStripMenuItem,
            this.exercicio02ToolStripMenuItem,
            this.exercicio03ToolStripMenuItem,
            this.exercicio04ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exercicio01ToolStripMenuItem
            // 
            this.exercicio01ToolStripMenuItem.Name = "exercicio01ToolStripMenuItem";
            this.exercicio01ToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.exercicio01ToolStripMenuItem.Text = "Exercicio 0&1";
            this.exercicio01ToolStripMenuItem.Click += new System.EventHandler(this.exercicio01ToolStripMenuItem_Click);
            // 
            // exercicio02ToolStripMenuItem
            // 
            this.exercicio02ToolStripMenuItem.Name = "exercicio02ToolStripMenuItem";
            this.exercicio02ToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.exercicio02ToolStripMenuItem.Text = "Exercicio 0&2";
            this.exercicio02ToolStripMenuItem.Click += new System.EventHandler(this.exercicio02ToolStripMenuItem_Click);
            // 
            // exercicio03ToolStripMenuItem
            // 
            this.exercicio03ToolStripMenuItem.Name = "exercicio03ToolStripMenuItem";
            this.exercicio03ToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.exercicio03ToolStripMenuItem.Text = "Exercicio 0&3";
            this.exercicio03ToolStripMenuItem.Click += new System.EventHandler(this.exercicio03ToolStripMenuItem_Click);
            // 
            // exercicio04ToolStripMenuItem
            // 
            this.exercicio04ToolStripMenuItem.Name = "exercicio04ToolStripMenuItem";
            this.exercicio04ToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.exercicio04ToolStripMenuItem.Text = "Exercicio 0&4";
            this.exercicio04ToolStripMenuItem.Click += new System.EventHandler(this.exercicio04ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exercicio01ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercicio02ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercicio03ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercicio04ToolStripMenuItem;
    }
}

